# Youtube Tutorial : https://www.youtube.com/watch?v=O2q7FefB1Zg

# Streaming-24-7-RPC
Allows you to keep your account status as streaming. It also allows you to set a gif link as your image in your rpc and have 2 buttons. It is fully customizable!

# DO NOT GIVE YOUR TOKEN TO OTHERS!
**Giving your token to someone else will give them the ability to log into your account without the password or 2FA.**

# DO NOT INVITE SOMEBODY TO YOUR REPL!
**Inviting somebody to your repl literally means that your giving them full access to your repl including your secrets tab.**

> ⭐ Feel free to Star the Repository if this helped you! ;)
>                                                                                
> Streaming-24-7-RPC by mrnekrozyt is licensed under Attribution 4.0 International

