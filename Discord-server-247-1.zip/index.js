const Discord = require('discord.js-selfbot-v13');
const client = new Discord.Client({
  readyStatus: false,
  checkUpdate: false
});

const keepAlive = require('./server.js');
keepAlive();

function formatTime() { //Credits to himika#0001 and never#0001
  const date = new Date();
  const options = {
    timeZone: 'America/New_York', //https://www.zeitverschiebung.net/en/ and find your city and enter here
    hour12: true,
    hour: 'numeric',
    minute: 'numeric'
  };
  return new Intl.DateTimeFormat('en-US', options).format(date);
}

client.on('ready', async () => {
  console.clear();
  console.log(`${client.user.tag} - rich presence started!`);

  const r = new Discord.RichPresence()
    .setApplicationId('1179351100189589544')
    .setType('STREAMING')
    .setURL('https://twitch.tv/developer') //Must be a youtube video link 
    .setState('Minecraft')
    .setName('KamisatoAyato')
    .setDetails(`game [${formatTime()}]`)
    .setStartTimestamp(Date.now())
 .setAssetsLargeImage('https://media.discordapp.net/attachments/1041607183906906133/1171667145520840734/received_6915122411934598.gif?ex=6594e210&is=65826d10&hm=3d20141834f2e6e39a289ad20978b02d56632853ba36bf5ff8a2577784f6dc92&') //You can put links in tenor or discord and etc.
    .setAssetsLargeText('KamisatoAyato') //Text when you hover the Large image
    .setAssetsSmallImage('https://cdn.discordapp.com/emojis/1077472449068810291.gif?v=1&size=48&quality=lossless') //You can put links in tenor or discord and etc.
    .setAssetsSmallText('Ayato') //Text when you hover the Small image
    .addButton('youtube','https://youtube.com/@Phanit18999?si=6epkFyx9Cj7Pf2ze')
    .addButton('Facebook', 'https://www.facebook.com/profile.php?id=100041931158714&mibextid=ZbWKwL')
    .addButton('discord', 'https://discord.gg/Z6YEhHwT2u');
  client.user.setActivity(r);
  client.user.setPresence({ status: "dnd" }); //dnd, online, idle, offline

  let prevTime = null;
  setInterval(() => {
    const newTime = formatTime();
    if (newTime !== prevTime) {
      const newDetails = `game [${newTime}]`;
      r.setDetails(newDetails);
      client.user.setActivity(r);
      prevTime = newTime;
    }
  }, 1000); // Update every second
});

const mySecret = process.env['TOKEN'];
client.login(mySecret);